<?php 
header('Content-Type: text/html; charset=utf-8');

//variaveis
$nome = $_POST["nome"];
$salario = $_POST["salario"];
$emprestimo =$_POST["emprestimo"];
$prestacao = $_POST["prestacao"];
$porcentagem =  ($salario * 30) / 100;
$valor_prestacao = $emprestimo / $prestacao;


if(isset($_POST["Calcular"]) &&
isset($_POST["nome"]) && !empty ($_POST["nome"]) &&
isset($_POST["salario"]) && !empty ($_POST["salario"]) &&
isset($_POST["emprestimo"]) && !empty ($_POST["emprestimo"]) &&
isset($_POST["prestacao"]) && !empty ($_POST["prestacao"])){

    

    if ($valor_prestacao > $porcentagem ){
        echo "Erro";
    }
    else{
        echo "<br> O nome é: ".$nome; 
        echo "<br> O salario é R$: ".$salario; 
        echo " <br> O emprestimo é R$: ".$emprestimo;
        echo " <br> O prestação é R$: ".$prestacao;
    }
   
}
 

?>
